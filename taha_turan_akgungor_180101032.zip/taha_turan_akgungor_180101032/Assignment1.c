#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define NUMBEROF_THREAD 1

int sumof_th_result[NUMBEROF_THREAD] = {};
int part = 0;

int string_size, read_size;
int* numbers;
int counter = 0;
int sizeof_numbers_arr = 1024;
char temp[3];
int temp_counter = 0;

void add_to_arr(){
    numbers[counter] = atoi(temp);
    counter++;

    temp[0]=NULL;
    temp[1]=NULL;
    temp[2]=NULL;
    temp_counter = 0;
}

void check_arr_size(int numberof_int){
    if(numberof_int +1 == sizeof_numbers_arr){
        sizeof_numbers_arr *= 2;
        numbers = realloc(numbers,sizeof_numbers_arr * sizeof(int));
    }
}

void* sum_array(void* arg){

    for(int i = part * (sizeof_numbers_arr / NUMBEROF_THREAD); i < (part + 1) * (sizeof_numbers_arr / NUMBEROF_THREAD); i++)
        sumof_th_result[part] += numbers[i];

    part++;
}



char* ReadFile(char *filename)
{
   char *buffer = NULL;
   FILE *handler = fopen(filename, "r");

   if (handler)
   {
       fseek(handler, 0, SEEK_END);
       string_size = ftell(handler);
       rewind(handler);

       buffer = (char*) malloc(sizeof(char) * (string_size + 1) );

       read_size = fread(buffer, sizeof(char), string_size, handler);

       buffer[string_size] = '\0';

       fclose(handler);
    }

    return buffer;
}

int main()
{
    char *string = ReadFile("/home/tatu/Desktop/input_file.txt");

    numbers = (int*)calloc(sizeof_numbers_arr,sizeof(int));


    int numberof_int = 0;

    for(int i = 0; i < read_size+1; i++){
        if(string[i] == ','){
            add_to_arr();

        }else if(string[i] == ' '){
            check_arr_size(numberof_int);


        }else if(i == read_size){
            numbers[counter] = atoi(temp);
        }else{
            temp[temp_counter] = string[i];
            temp_counter++;
            numberof_int++;
        }
    }

    pthread_t threads[NUMBEROF_THREAD];

    for(int i = 0; i < NUMBEROF_THREAD; i++){
        pthread_create(&threads[i], NULL, sum_array, (void*)NULL);
        pthread_join(threads[i], NULL);
    }

    int total_sum = 0;
    for(int i = 0; i < NUMBEROF_THREAD; i++)
        total_sum += sumof_th_result[i];

    printf("Number of Threads: %d \n",NUMBEROF_THREAD);
    printf("Threads Total: %d \n\n", total_sum);



    /*-------------------------------------------------------------*/
    /*                       Naive Solution                        */

    int tsum=0;
   for(int i =0; i<sizeof_numbers_arr; i++){
        tsum+=numbers[i];

   }
   printf("Naive Total: %d \n ", tsum);


    return 0;
}
